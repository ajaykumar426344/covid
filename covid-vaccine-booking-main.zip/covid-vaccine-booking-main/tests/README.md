# Captcha relates issues
There are some issues reported by folks related to captach which are encountered at last step of booking. 
This test is added to ensure that your setup is correct so don't have to know these things at the time of booking :-)

## Reported issues
- https://github.com/bombardier-gif/covid-vaccine-booking/issues/32
- https://github.com/bombardier-gif/covid-vaccine-booking/issues/23
- https://github.com/bombardier-gif/covid-vaccine-booking/issues/30

# How to verify ?
1. Go to `tests` directory. `cd tests`
2. `python captcha_tests.py` and follow the steps

   If you see message below then you are all set for booking :-)

   `Yeah !!! you have entered captcha. This means you are all set to render required captcha at the time of booking ...`
