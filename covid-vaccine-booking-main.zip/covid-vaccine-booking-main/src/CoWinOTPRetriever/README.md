CoWIN OTP Retriever
=================

1. Install the Android application: [APK](../../CoWinOtpRetreiver.apk).
2. Allow the app to run in background.  
![image](https://user-images.githubusercontent.com/3753228/118129520-ea1ec800-b419-11eb-962c-0e2d5ae7edf3.png)
3. Grant sms access to allow the app to read CoWIN OTP sms.  
![image](https://user-images.githubusercontent.com/3753228/117947493-df870480-b32d-11eb-923d-47efa55f9586.png)
3. Enter 10 digit mobile number registered on the CoWIN portal, enter the KV DB bucket key and switch ON the OTP Listener.  
![image](https://user-images.githubusercontent.com/3753228/117948585-e4988380-b32e-11eb-9837-9abdda21c23e.png)
6. If the OTP is successfully sent to the key value store, you will see the status as shown below.  
![image](https://user-images.githubusercontent.com/3753228/117949979-54f3d480-b330-11eb-8568-fec8284e138b.png)
